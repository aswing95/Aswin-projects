package com.bharath.flightcheckin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightcheckinApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightcheckinApplication.class, args);
	}
}
